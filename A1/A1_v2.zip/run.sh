#!/bin/bash
clang main.c -o main
./main 4
